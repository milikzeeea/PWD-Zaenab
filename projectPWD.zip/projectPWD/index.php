<!DOCTYPE html>
<html>
    <head>
        <title>Belajar PHP - Tampilkan identitas</title>
        <link href="style.css" rel="stylesheet">
        
</head>
<body>
    <a href="tambah.php">+ TAMBAH IDENTITAS</a>
    <br />
    <br />
    <table border="1">
        <tr>
            <th>NO</th>
            <th>Nomer Identitas</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor HP</th>
            <th>Jenis Kelamin</th>
            <th>Kode pos</th>
            <th>Aksi</th>
</tr>
<?php
include 'connect.php';
$no = 1;
$data = mysqli_query($db, "SELECT* FROM identitas");
while ($d = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $d['no_identitas']; ?></td>
        <td><?php echo $d['nama']; ?></td>
        <td><?php echo $d['alamat']; ?></td>
        <td><?php echo $d['no_telepon']; ?></td>
        <td><?php echo $d['Jk']; ?></td>
        <td><?php echo $d['kodepos']; ?></td>
        <td>
            <a href="edit.php?id=<?php echo $d['no_identitas']; ?>">EDIT</a>
            <a href="hapus.php?id=<?php echo $d['no_identitas']; ?>">HAPUS</a>
</td>
</tr>
<?php
}

?>
</table>
</body>
</html>
