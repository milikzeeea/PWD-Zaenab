<?php
include("connect.php");

if (isset($_POST['daftar'])){
    
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];
    $Jk = $_POST['Jk'];
    $kodepos = $_POST['kodepos'];

    mysqli_query($db, "INSERT INTO identitas VALUES ('','$nama', '$alamat', '$no_telepon', '$Jk', '$kodepos')");

    //mengalihkan halaman kembali ke index.php
    header("location:index.php");
}