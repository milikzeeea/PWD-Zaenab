<?php
include("connect.php");

if (isset($_POST['simpan'])) {

    $id = $_POST['no_identitas'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];
    $Jk = $_POST['Jk'];
    $kodepos = $_POST['kodepos'];

    $sql = "UPDATE identitas SET nama='$nama', alamat='$alamat', no_telepon='$no_telepon', Jk='$Jk', kodepos='$kodepos' WHERE no_identitas=$id";
    $query = mysqli_query($db, $sql);

    if ($query) {

        header('Location: index.php');
    } else {

        die("Gagal menyimpan perubahan...");
    }
}
 else {
    die("Akses dilarang...");
}
