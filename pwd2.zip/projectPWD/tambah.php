<!DOCTYPE html>
<html>
    <head>
        <title>Belajar PHP | Tampilkan identitas</title>
</head>
<body>
    <header>
        <h3>Tambah Identitas</h3>
</header>
<form action= "proses_tambah.php" method="POST">
    <fieldset>
        <p>
            <label for="nama">Nama:</label>
            <input type="text" name="nama" placeholder="nama lengkap"/>
</p>
<p>
            <label for="alamat">Alamat:</label>
            <textarea name="alamat"></textarea>
</p>
<p>
            <label for="no_telepon">Nomor HP: </label>
            <textarea name="no_telepon"></textarea>
</p>
<p>
            <label for="Jk">Jenis Kelamin: </label>
            <label><input type="radio" name="Jk" value="laki-laki"> Laki -laki</label>
            <label><input type="radio" name="Jk" value="perempuan"> perempuan</label>
</p>
<p>
            <label for="kodepos">Kodepos: </label>
            <input type="text" name="kodepos" placeholder="kodepos"/>
</p>
<p>
    <input type="submit" value="Daftar" name="daftar"/>
</p>

</fieldset>
</form>
</body>
</html>

